# Dockerized Project with Flask, Symfony, and Vue.js

## Prerequisites

- Docker
- Docker Compose

## Installation

### 1. Clone the repository

```sh
git clone <REPOSITORY_URL>
cd <REPOSITORY_NAME>