from flask import Flask, request, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://root:Toptop2025$$@localhost:5432/notes_db'
db = SQLAlchemy(app)
CORS(app)

NOTE_NOT_FOUND = "Note not found"

class NoteInDB(db.Model):
    __tablename__ = 'notes'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String, nullable=False)
    content = db.Column(db.String, nullable=False)

with app.app_context():
    db.create_all()

@app.route('/notes/', methods=['POST'])
def create_note():
    data = request.get_json()
    new_note = NoteInDB(title=data['title'], content=data['content'])
    db.session.add(new_note)
    db.session.commit()
    return jsonify({'message': 'Note created successfully'}), 201

@app.route('/notes/', methods=['GET'])
def read_notes():
    notes = NoteInDB.query.all()
    return jsonify([{'id': note.id, 'title': note.title, 'content': note.content} for note in notes])

@app.route('/notes/<int:note_id>/', methods=['GET'])
def read_note(note_id):
    note = NoteInDB.query.get(note_id)
    if note is None:
        abort(404, description=NOTE_NOT_FOUND)
    return jsonify({'id': note.id, 'title': note.title, 'content': note.content})

@app.route('/notes/<int:note_id>/', methods=['PUT'])
def update_note(note_id):
    note = NoteInDB.query.get(note_id)
    if note is None:
        abort(404, description=NOTE_NOT_FOUND)
    data = request.get_json()
    note.title = data['title']
    note.content = data['content']
    db.session.commit()
    return jsonify({'message': 'Note updated successfully'})

@app.route('/notes/<int:note_id>/', methods=['DELETE'])
def delete_note(note_id):
    note = NoteInDB.query.get(note_id)
    if note is None:
        abort(404, description=NOTE_NOT_FOUND)
    db.session.delete(note)
    db.session.commit()
    return jsonify({'message': 'Note deleted successfully'}), 200

if __name__ == '__main__':
    app.run(debug=True)