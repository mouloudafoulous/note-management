<template>
  <div class="container mt-5">
    <h1 class="text-center mb-4">Note Management System</h1>
    <div class="row justify-content-center">
      <div class="col-md-8">
        <form @submit.prevent="submitNote" class="card p-4 shadow-sm">
          <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control" id="title" v-model="noteForm.title" required>
          </div>
          <div class="mb-3">
            <label for="content" class="form-label">Content</label>
            <textarea class="form-control" id="content" v-model="noteForm.content" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary w-100">{{ isEditing ? 'Update' : 'Submit' }}</button>
        </form>
      </div>
    </div>

    <table class="table table-striped mt-4">
      <thead>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Content</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="note in paginatedNotes" :key="note.id">
          <td>{{ note.id }}</td>
          <td>{{ note.title }}</td>
          <td>{{ note.content }}</td>
          <td>
            <button class="btn btn-warning btn-sm" @click="editNote(note)"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-danger btn-sm" @click="deleteNote(note.id)"><i class="bi bi-trash"></i></button>
          </td>
        </tr>
      </tbody>
    </table>

    <nav>
      <ul class="pagination justify-content-center">
        <li class="page-item" :class="{ disabled: currentPage === 1 }">
          <a class="page-link" href="#" @click.prevent="changePage(currentPage - 1)">Previous</a>
        </li>
        <li class="page-item" v-for="page in totalPages" :key="page" :class="{ active: currentPage === page }">
          <a class="page-link" href="#" @click.prevent="changePage(page)">{{ page }}</a>
        </li>
        <li class="page-item" :class="{ disabled: currentPage === totalPages }">
          <a class="page-link" href="#" @click.prevent="changePage(currentPage + 1)">Next</a>
        </li>
      </ul>
    </nav>
  </div>

</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      notes: [],
      noteForm: {
        id: null,
        title: '',
        content: ''
      },
      isEditing: false,
      currentPage: 1,
      notesPerPage: 20
    };
  },
  computed: {
    totalPages() {
      return Math.ceil(this.notes.length / this.notesPerPage);
    },
    paginatedNotes() {
      const start = (this.currentPage - 1) * this.notesPerPage;
      const end = start + this.notesPerPage;
      return this.notes.slice(start, end);
    }
  },
  created() {
    this.fetchNotes();
  },
  methods: {
    fetchNotes() {
      axios.get('http://localhost:5000/notes/')
        .then(response => {
          this.notes = response.data;
        })
        .catch(error => {
          console.error(error);
        });
    },
    submitNote() {
      if (this.isEditing) {
        axios.put(`http://localhost:5000/notes/${this.noteForm.id}/`, this.noteForm)
          .then(() => {
            this.fetchNotes();
            this.resetForm();
          })
          .catch(error => {
            console.error(error);
          });
      } else {
        axios.post('http://localhost:5000/notes/', this.noteForm)
          .then(() => {
            this.fetchNotes();
            this.resetForm();
          })
          .catch(error => {
            console.error(error);
          });
      }
    },
    editNote(note) {
      this.noteForm = { ...note };
      this.isEditing = true;
    },
    deleteNote(id) {
      axios.delete(`http://localhost:5000/notes/${id}/`)
        .then(() => {
          this.fetchNotes();
        })
        .catch(error => {
          console.error(error);
        });
    },
    resetForm() {
      this.noteForm = {
        id: null,
        title: '',
        content: ''
      };
      this.isEditing = false;
    },
    changePage(page) {
      if (page > 0 && page <= this.totalPages) {
        this.currentPage = page;
      }
    }
  }
};
</script>

<style>
/* Ajoutez ici vos styles personnalisés */
</style>